# Medical OMR Scanner

A static GitHub Pages OMR scanner using OpenCV.js.

## Features

- Take an OMR photo on mobile
- Upload an existing photo
- Optional live camera capture
- Automatic perspective correction
- 100-question A/B/C/D detection
- Detects blank and multiple-mark questions
- Confidence estimate
- Optional 100-answer grading
- CSV export
- No backend/server required

## OMR layout

The detector is calibrated for the supplied Medical Admission 2025-26 blank OMR:

- 1–25: first answer table
- 26–50: second table
- 51–75: third table
- 76–100: fourth table

The coordinates are normalized after perspective correction to 1014×1550.

## GitHub Pages

1. Create a repository.
2. Upload `index.html` and `style.css`.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select `main` and `/root`.
6. Save.
7. Open the generated GitHub Pages URL.

## Important

This is a layout-specific scanner. For real exam use, test it with many photos containing actual filled OMR sheets and adjust the thresholds in `index.html` if necessary.

Best photos:
- whole sheet visible
- all four edges visible
- camera parallel to the paper
- bright, even lighting
- no glare
- dark, clearly filled bubbles
